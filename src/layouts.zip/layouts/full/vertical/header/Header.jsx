import { useState } from 'react';

import {
  IconButton,
  Box,
  AppBar,
  useMediaQuery,
  Toolbar,
  styled,
  Stack,
  Divider,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import { IconCategory2, IconMenu2, IconMoon, IconSun, IconX } from '@tabler/icons-react';
import Notifications from './Notification';
import Profile from './Profile';
import Search from './Search';
import Language from './Language';
import Navigation from './Navigation';
import MobileRightSidebar from './MobileRightSidebar';
import config from 'src/context/config';
import { useContext } from 'react';
import { useTheme } from '@mui/material/styles';
import { CustomizerContext } from 'src/context/CustomizerContext';
import api from '../../../../api/landlord/landlord_api';
import axios from 'axios';
import { AuthContext } from '../../../../context/AgentContext/auth';

const Header = () => {
  const lgUp = useMediaQuery((theme) => theme.breakpoints.up('lg'));
  const lgDown = useMediaQuery((theme) => theme.breakpoints.down('lg'));
  const {
    activeMode,
    setActiveMode,
    setIsCollapse,
    isCollapse,
    isMobileSidebar,
    setIsMobileSidebar,
  } = useContext(CustomizerContext);

  const TopbarHeight = config.topbarHeight;

  const theme = useTheme();
  const borderColor = theme.palette.divider;

  const AppBarStyled = styled(AppBar)(({ theme }) => ({
    boxShadow: 'none',
    backgroundColor: theme.palette.background.paper,
    justifyContent: 'center',
    backdropFilter: 'blur(4px)',
    zIndex: 1200,
    // Account for sidebar width on large screens
    [theme.breakpoints.up('lg')]: {
      minHeight: TopbarHeight,
      marginLeft:
        isCollapse === 'mini-sidebar' ? `${config.miniSidebarWidth}px` : `${config.sidebarWidth}px`,
    },
    // On smaller screens, full width
    [theme.breakpoints.down('lg')]: {
      minHeight: TopbarHeight,
      marginLeft: 0,
    },
  }));
  const ToolbarStyled = styled(Toolbar)(({ theme }) => ({
    width: '100%',
    color: `${theme.palette.text.primary} !important`,
    paddingLeft: '288px !important',
    paddingRight: '16px !important',
    // On smaller screens, reduce padding
    [theme.breakpoints.down('lg')]: {
      paddingLeft: '18px !important',
    },
  }));

  const CollpaseMenubar = styled(Box)(({ theme }) => ({
    position: 'absolute',
    left: '4px',
    top: '4px',
    right: '4px',
    padding: '7px 15px',
    background: theme.palette.background.paper,
    border: `1px solid ${borderColor}`,
    zIndex: 1,
    borderRadius: '7px',
  }));

  const [isVisible, setIsVisible] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const { isImpersonating, stopImpersonation, user } = useContext(AuthContext);

  const handleStopImpersonation = async () => {
    setConfirmOpen(false);
    await stopImpersonation(); // existing function handles the rest
  };

  return (
    <AppBarStyled
      position="fixed"
      color="default"
      sx={{
        ...(lgUp && {
          marginLeft:
            isCollapse === 'mini-sidebar'
              ? `${config.miniSidebarWidth}px`
              : `${config.sidebarWidth}px`,
        }),
      }}
    >
      <ToolbarStyled
        sx={{
          paddingLeft: lgUp
            ? `${(isCollapse === 'mini-sidebar' ? config.miniSidebarWidth : config.sidebarWidth) + 18}px !important`
            : '18px !important',
        }}
      >
        {/* ------------------------------------------- */}
        {/* Toggle Button Sidebar */}
        {/* ------------------------------------------- */}
        <IconButton
          color="inherit"
          aria-label="menu"
          onClick={() => {
            if (lgUp) {
              isCollapse === 'full-sidebar'
                ? setIsCollapse('mini-sidebar')
                : setIsCollapse('full-sidebar');
            } else {
              setIsMobileSidebar(!isMobileSidebar);
            }
          }}
        >
          <IconMenu2 size="21" />
        </IconButton>

        {/* ------------------------------------------- */}
        {/* Search Dropdown */}
        {/* ------------------------------------------- */}
        {lgUp ? (
          <>
            {' '}
            <Search />{' '}
          </>
        ) : null}
        {lgUp ? <>{/* <Navigation /> */}</> : null}

        {isImpersonating && (
          <Box
            sx={{
              // bgcolor: 'warning.main',
              bgcolor: '#593196',
              color: '#ffffff',
              px: { xs: 1, sm: 2 },
              py: 0.5,
              borderRadius: 1,
              display: 'flex',
              alignItems: 'center',
              gap: { xs: 0.5, sm: 1 },
              ml: { xs: 1, sm: 2 },
              maxWidth: { xs: '160px', sm: 'none' },
              overflow: 'hidden',
            }}
          >
            <Typography
              variant="body2"
              sx={{
                display: { xs: 'none', sm: 'block' },
                whiteSpace: 'nowrap',
              }}
            >
              Logged in as Agent
            </Typography>
            <Typography
              variant="body2"
              sx={{
                display: { xs: 'block', sm: 'none' },
                whiteSpace: 'nowrap',
                fontSize: '11px',
              }}
            >
              Impersonating
            </Typography>
            <Button
              size="small"
              variant="outlined"
              color="inherit"
              onClick={() => setConfirmOpen(true)}
              sx={{
                whiteSpace: 'nowrap',
                fontSize: { xs: '10px', sm: '13px' },
                px: { xs: 0.75, sm: 1.5 },
                minWidth: 'unset',
              }}
            >
              {lgUp ? 'Return to my account' : 'Exit'}
            </Button>
          </Box>
        )}

        <Box flexGrow={1} />
        <Stack direction="row" gap={1} alignItems="center">
          {/* ------------------------------------------- */}
          {/* Light/Dark Theme */}
          {/* ------------------------------------------- */}
          <IconButton color="inherit">
            {activeMode === 'light' ? (
              <IconMoon size="21" onClick={() => setActiveMode('dark')} />
            ) : (
              <IconSun size="21" onClick={() => setActiveMode('light')} />
            )}
          </IconButton>

          {/* ------------------------------------------- */}
          {/* Language Dropdown */}
          {/* ------------------------------------------- */}
          {/* {lgUp ? (<> <Language /> </>) : null} */}

          {/* ------------------------------------------- */}
          {/* Notification Dropdown */}
          {/* ------------------------------------------- */}
          {lgUp ? (
            <>
              {' '}
              <Notifications />{' '}
            </>
          ) : null}

          {lgDown ? (
            <IconButton color="inherit" onClick={() => setIsVisible(!isVisible)}>
              <IconCategory2 size="21" />
            </IconButton>
          ) : null}

          {lgDown ? <MobileRightSidebar /> : null}

          {/* ------------------------------------------- */}

          <Profile />

          {isVisible && (
            <CollpaseMenubar>
              <Stack direction="row" justifyContent="space-between" spacing={1}>
                <Box display="flex" gap={1}>
                  <Notifications />
                  <Language />
                  <Search />
                </Box>
                <IconButton color="inherit" onClick={() => setIsVisible(!isVisible)}>
                  <IconX size="21" />
                </IconButton>
              </Stack>
            </CollpaseMenubar>
          )}
        </Stack>
      </ToolbarStyled>

      {/* Confirmation Dialog */}
      <Dialog open={confirmOpen} onClose={() => setConfirmOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 600 }}>Return to your account?</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary">
            You are currently impersonating{' '}
            <strong>{user?.organization?.organization_name || 'this agent'}</strong>. Returning will
            restore your admin session.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2, gap: 1 }}>
          <Button variant="outlined" color="inherit" onClick={() => setConfirmOpen(false)}>
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={handleStopImpersonation}
            sx={{ bgcolor: '#593196', color: '#ffffff', '&:hover': { bgcolor: '#4a2880' } }}
          >
            Yes, return to my account
          </Button>
        </DialogActions>
      </Dialog>
    </AppBarStyled>
  );
};

export default Header;
